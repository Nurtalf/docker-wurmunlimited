BEGIN TRANSACTION;
/* No logs inserted on install. */
COMMIT;
